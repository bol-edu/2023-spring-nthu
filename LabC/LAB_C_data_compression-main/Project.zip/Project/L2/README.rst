===============
L2 Kernel Demos
===============

Overview
--------

The L2 section uses the data compression algorithm which internally uses the optimized hardware modules to showcase various kernel demos.
