Xilinx Gzip Multibyte Dynamic Block Streaming Decompress HLS Test
=================================================================

**Description:** Test Design to validate core Gzip decompress module

**Top Function:** gzipMultiByteDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
gzip_decompress_test     9.0K      6.3K      11    2 
======================== ========= ========= ===== ===== 