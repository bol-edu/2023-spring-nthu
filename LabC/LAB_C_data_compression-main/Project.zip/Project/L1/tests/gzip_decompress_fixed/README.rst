Xilinx Gzip Multibyte Fixed Block Streaming Decompress HLS Test
===============================================================

**Description:** Test Design to validate core Gzip decompress module

**Top Function:** gzipMultiByteDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
gzip_decompress_test     4.3K      3.0K      1     2 
======================== ========= ========= ===== ===== 