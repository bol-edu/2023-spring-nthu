Xilinx ZSTD quadcore compress HLS Test
======================================

**Description:** Test Design to validate ZSTD compression quadcore design.

**Top Function:** compressFile

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
zstd_qc_compress         22.0K     19.8K     96    8 
======================== ========= ========= ===== ===== 