Xilinx Zlib 8Kb block size Streaming Decompress HLS Test
========================================================

**Description:** Test Design to validate core zlib decompress module

**Top Function:** zlibMultiByteDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
zlib_decompress_test     7.3K      5.7K      4     0 
======================== ========= ========= ===== ===== 