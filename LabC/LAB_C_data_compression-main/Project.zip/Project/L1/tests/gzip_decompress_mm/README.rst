Xilinx Gzip Multibyte Decompress Memory Mapped HLS Test
=======================================================

**Description:** Test Design to validate core Gzip decompress module using dynamic huffman decoder

**Top Function:** gzipDecompressMM

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
gzip_decompress_test     11.8K     13.1K     24 