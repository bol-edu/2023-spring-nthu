Xilinx Downsizer HLS Test
=========================

**Description:** Test Design to validate Downsizer module.

**Top Function:** streamDownsizerRun

