Xilinx LZ4 Compress HLS Test
============================

**Description:** Test Design to validate LZ4 core compress module

**Top Function:** lz4CompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
lz4_compress_test        2.8K      3.2K      10    6 
======================== ========= ========= ===== ===== 