Xilinx GZIP Compress Streaming 16KB AXI Test
============================================

**Description:** Test Design to validate Streaming GZIP 16KB static compression

**Top Function:** gzipcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
gzip_compress_test       34.1K     36.4K     215       48 
======================== ========= ========= ========= ===== 