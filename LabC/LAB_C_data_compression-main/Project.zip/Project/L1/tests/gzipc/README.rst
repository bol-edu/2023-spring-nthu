Xilinx GZIP 32KB Compress Streaming Test
========================================

**Description:** Test Design to validate Streaming GZIP 32KB compression

**Top Function:** gzipcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
gzip_compress_test       52.7K     48.4K     284       64 
======================== ========= ========= ========= ===== 