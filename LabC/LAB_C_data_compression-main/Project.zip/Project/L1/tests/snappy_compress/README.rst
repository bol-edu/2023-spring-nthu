Xilinx Snappy Compress HLS Test
===============================

**Description:** Test Design to validate core Snappy compress module

**Top Function:** snappyCompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
snappy_compress_test     2.8K      3.2K      8     6 
======================== ========= ========= ===== ===== 