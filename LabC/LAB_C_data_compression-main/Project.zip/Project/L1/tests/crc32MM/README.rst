Xilinx CRC32 Memory Mapped HLS Test
===================================

**Description:** Test Design to validate Xilinx CRC32 module

**Top Function:** hls_crc32MM

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
crc32MM                  2.9K      4.5K      24    0 
======================== ========= ========= ===== ===== 