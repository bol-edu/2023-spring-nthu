Xilinx GZIP 8KB Compress Streaming Test
=======================================

**Description:** Test Design to validate Streaming GZIP 8KB compression

**Top Function:** gzipcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
gzip_compress_test       55.8K     52.5K     202       48 
======================== ========= ========= ========= ===== 