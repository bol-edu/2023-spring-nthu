Xilinx Checksum32 Memory Mapped HLS Test
========================================

**Description:** Test Design to validate Xilinx Checksum32 module

**Top Function:** hls_checksum32MM

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
checksum32MM             3.6K      5.7K      24    0 
======================== ========= ========= ===== ===== 