Xilinx Upsizer HLS Test
=======================

**Description:** Test Design to validate Upsizer module

**Top Function:** hls_streamUpsizer

