Xilinx CRC32 Sizeless HLS Test
==============================

**Description:** Test Design to validate Xilinx CRC32 module

**Top Function:** hls_crc32

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
crc32                    0.5K      0.5K      8     0 
======================== ========= ========= ===== ===== 