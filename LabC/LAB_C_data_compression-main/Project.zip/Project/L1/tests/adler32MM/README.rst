Xilinx Adler32 Memory Mapped HLS Test
=====================================

**Description:** Test Design to validate Xilinx Adler32 module

**Top Function:** hls_adler32MM

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
adler32MM                3.0K      5.0K      8     0 
======================== ========= ========= ===== ===== 