Xilinx Lz4 Multibyte Decompress HLS Test
========================================

**Description:** Test design to validate LZ4 Multi Byte Decompress Module

**Top Function:** lz4DecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
lz4_decompress_test      4.7K      4.0K      0     4 
======================== ========= ========= ===== ===== 