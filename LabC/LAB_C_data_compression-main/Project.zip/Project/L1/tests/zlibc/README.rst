Xilinx ZLIB 32KB Compress Streaming AXI Test
============================================

**Description:** Test Design to validate Streaming ZLIB 32KB compression

**Top Function:** zlibcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
zlib_compress_test       53.0K     48.5K     274       64 
======================== ========= ========= ========= ===== 