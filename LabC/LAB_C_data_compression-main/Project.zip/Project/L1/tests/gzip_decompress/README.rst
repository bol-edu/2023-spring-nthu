Xilinx Gzip Multibyte Decompress HLS Test
=========================================

**Description:** Test Design to validate core Gzip decompress module using dynamic huffman decoder

**Top Function:** gzipMultiByteDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
gzip_decompress_test     9.6K      6.5K      11    2 
======================== ========= ========= ===== ===== 