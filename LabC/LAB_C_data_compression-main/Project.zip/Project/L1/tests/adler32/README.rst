Xilinx Adler32 HLS Test
=======================

**Description:** Test Design to validate Xilinx Adler32 module

**Top Function:** hls_adler32

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
adler32                  0.2K      0.2K      0     0 
======================== ========= ========= ===== ===== 