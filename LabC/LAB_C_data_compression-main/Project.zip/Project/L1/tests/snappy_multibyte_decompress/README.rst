Xilinx Snappy Multibyte Decompress HLS Test
===========================================

**Description:** Test Design to validate Snappy MultiByte Decompress module

**Top Function:** snappyDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
snappy_decompress_test   5.5K      4.9K      0     4 
======================== ========= ========= ===== ===== 