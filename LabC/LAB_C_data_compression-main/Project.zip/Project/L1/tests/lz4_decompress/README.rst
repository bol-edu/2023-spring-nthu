Xilinx Lz4 Decompress HLS Test
==============================

**Description:** Test Design to validate LZ4 core decompress module

**Top Function:** lz4DecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
lz4_decompress_test      0.7K      0.6K      32    0 
======================== ========= ========= ===== ===== 