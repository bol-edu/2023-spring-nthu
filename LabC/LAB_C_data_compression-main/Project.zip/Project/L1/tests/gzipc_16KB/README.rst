Xilinx GZIP 16KB Compress Streaming Test
========================================

**Description:** Test Design to validate Streaming GZIP 16KB compression

**Top Function:** gzipcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
gzip_compress_test       56.8K     52.8K     328       48 
======================== ========= ========= ========= ===== 