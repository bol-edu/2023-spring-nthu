Xilinx ZSTD compress HLS Test
=============================

**Description:** Test Design to validate ZSTD compression

**Top Function:** compressFile

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
zstd_compress            28.8K     31.8K     97    14 
======================== ========= ========= ===== ===== 