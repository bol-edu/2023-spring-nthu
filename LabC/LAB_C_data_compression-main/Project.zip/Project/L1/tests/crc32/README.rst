Xilinx CRC32 HLS Test
=====================

**Description:** Test Design to validate Xilinx CRC32 module

**Top Function:** hls_crc32

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
crc32                    0.2K      0.2K      1     0 
======================== ========= ========= ===== ===== 