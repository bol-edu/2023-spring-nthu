Xilinx GZIP Compress Streaming 8KB AXI Test
===========================================

**Description:** Test Design to validate Streaming GZIP 8KB static compression

**Top Function:** gzipcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
gzip_compress_test       34.0K     36.3K     122       48 
======================== ========= ========= ========= ===== 