Xilinx GZIP 32KB Compress Memory Mapped HLS Test
================================================

**Description:** Test Design to validate Memory Mapped GZIP 32KB compression

**Top Function:** gzipcMulticoreMM

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
gzip_compress_test       53.0K     47.4K     260       64 
======================== ========= ========= ========= ===== 