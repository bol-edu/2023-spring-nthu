Xilinx ZLIB 8KB Compress Streaming AXI Test
===========================================

**Description:** Test Design to validate Streaming ZLIB 8KB compression

**Top Function:** zlibcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
zlib_compress_test       56.0K     52.6K     193       48 
======================== ========= ========= ========= ===== 