Xilinx ZSTD Decompress HLS Test
===============================

**Description:** Test Design to validate ZSTD decompression

**Top Function:** decompressFrame

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
zstd_decompress          28.1K     20.8K     36    5 
======================== ========= ========= ===== ===== 