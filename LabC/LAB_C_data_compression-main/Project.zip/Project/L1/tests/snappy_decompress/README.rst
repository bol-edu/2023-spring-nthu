Xilinx Snappy Decompress HLS Test
=================================

**Description:** Test Design to validate core Snappy decompress module

**Top Function:** snappyDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
snappy_decompress_test   0.7K      0.5K      32    0 
======================== ========= ========= ===== ===== 