Xilinx ZLIB 32KB Static Compress Streaming AXI Test
===================================================

**Description:** Test Design to validate Streaming ZLIB 32KB static compression

**Top Function:** zlibcMulticoreStreaming

Results
-------

======================== ========= ========= ========= ===== 
Module                   LUT       FF        BRAM_18K  URAM 
zlib_compress_test       34.3K     36.6K     79        64 
======================== ========= ========= ========= ===== 