Xilinx Snappy Dualcore Decompress HLS Test
==========================================

**Description:** Test Design to validate Snappy Dualcore Decompress module

**Top Function:** snappyDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
snappy_decompress_test   9.4K      8.1K      0     16 
======================== ========= ========= ===== ===== 