Xilinx Gzip Multibyte Dynamic Block Streaming Decompress HLS Test
=================================================================

**Description:** Test Design to validate core Gzip decompress module

**Top Function:** gzipMultiByteDecompressEngineRun

Results
-------

======================== ========= ========= ===== ===== 
Module                   LUT       FF        BRAM  URAM 
gzip_decompress_test     6.8K      5.3K      1     2 
======================== ========= ========= ===== ===== 